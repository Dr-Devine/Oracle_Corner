package com.example.oracle.repositories;

import com.example.oracle.models.Tarot;
import org.springframework.data.jpa.repository.JpaRepository;



public interface TarotRepository extends JpaRepository<Tarot, Long> {
}
